# WhatsApp AI Bot — Node.js + Baileys

## Fitur
- Login WhatsApp memakai QR
- `.menu`
- `.ping`
- `.ai <pertanyaan>`
- Auto AI opsional lewat `AUTO_AI=true`
- OpenAI Responses API
- Session Baileys disimpan di `auth_info_baileys`

## Jalankan lokal
1. Install Node.js 20+
2. Jalankan `npm install`
3. Isi environment variable berdasarkan `.env.example`
4. Jalankan `npm start`
5. Scan QR dari terminal melalui WhatsApp > Perangkat tertaut > Tautkan perangkat.

## Railway
Variables:
- OPENAI_API_KEY
- OPENAI_MODEL=gpt-5
- AUTO_AI=false
- PREFIX=.
- SESSION_DIR=./auth_info_baileys
- LOG_LEVEL=info

Start command: `npm start`

Catatan:
Folder auth pada filesystem deployment tidak selalu persisten. Untuk production, gunakan persistent volume/database untuk menyimpan kredensial/session secara aman.
