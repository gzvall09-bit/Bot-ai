import makeWASocket, {
  DisconnectReason,
  useMultiFileAuthState
} from "@whiskeysockets/baileys";
import { Boom } from "@hapi/boom";
import P from "pino";
import qrcode from "qrcode-terminal";
import OpenAI from "openai";

const SESSION_DIR = process.env.SESSION_DIR || "./auth_info_baileys";
const OPENAI_API_KEY = process.env.OPENAI_API_KEY;
const OPENAI_MODEL = process.env.OPENAI_MODEL || "gpt-5";
const AUTO_AI = String(process.env.AUTO_AI || "false").toLowerCase() === "true";
const PREFIX = process.env.PREFIX || ".";

if (!OPENAI_API_KEY) {
  console.error("ERROR: OPENAI_API_KEY belum diisi.");
  process.exit(1);
}

const openai = new OpenAI({ apiKey: OPENAI_API_KEY });
const logger = P({ level: process.env.LOG_LEVEL || "info" });

function getTextMessage(message) {
  if (!message?.message) return "";
  return (
    message.message.conversation ||
    message.message.extendedTextMessage?.text ||
    message.message.imageMessage?.caption ||
    message.message.videoMessage?.caption ||
    ""
  ).trim();
}

function getMenu() {
  return `
╭━━━〔 🤖 AI BOT 〕━━━╮
┃
┃ ${PREFIX}menu
┃ Menampilkan menu bot
┃
┃ ${PREFIX}ping
┃ Cek apakah bot aktif
┃
┃ ${PREFIX}ai <pertanyaan>
┃ Tanya AI
┃
╰━━━━━━━━━━━━━━━━━━╯

AI otomatis: ${AUTO_AI ? "AKTIF" : "MATI"}
`;
}

async function askAI(prompt) {
  const response = await openai.responses.create({
    model: OPENAI_MODEL,
    instructions:
      "Kamu adalah asisten AI WhatsApp yang ramah, singkat, membantu, dan menggunakan bahasa Indonesia kecuali pengguna meminta bahasa lain.",
    input: prompt,
    max_output_tokens: 700
  });
  return response.output_text?.trim() || "Maaf, AI tidak memberikan jawaban.";
}

async function startBot() {
  const { state, saveCreds } = await useMultiFileAuthState(SESSION_DIR);

  const sock = makeWASocket({
    auth: state,
    logger,
    printQRInTerminal: true
    browser: ["WhatsApp AI Bot", "Chrome", "1.0.0"],
    markOnlineOnConnect: false,
    syncFullHistory: false
  });

  sock.ev.on("creds.update", saveCreds);

  sock.ev.on("connection.update", async (update) => {
    const { connection, lastDisconnect, qr } = update;

    if (qr) {
      console.log("\n================================");
      console.log("SCAN QR DENGAN WHATSAPP");
      console.log("WhatsApp > Perangkat tertaut > Tautkan perangkat");
      console.log("================================\n");
      qrcode.generate(qr, { small: true });
    }

    if (connection === "open") {
      console.log("\n================================");
      console.log("✅ BOT WHATSAPP BERHASIL TERHUBUNG");
      console.log("================================\n");
    }

    if (connection === "close") {
      const statusCode =
        new Boom(lastDisconnect?.error)?.output?.statusCode;
      const shouldReconnect = statusCode !== DisconnectReason.loggedOut;

      console.log(
        "Koneksi WhatsApp terputus.",
        "Status:", statusCode,
        "Reconnect:", shouldReconnect
      );

      if (shouldReconnect) {
        setTimeout(() => startBot().catch(console.error), 5000);
      } else {
        console.log("Session logout. Hapus folder auth lalu login QR kembali.");
      }
    }
  });

  sock.ev.on("messages.upsert", async ({ messages, type }) => {
    if (type !== "notify") return;

    const msg = messages?.[0];
    if (!msg?.message || msg.key.fromMe) return;

    const jid = msg.key.remoteJid;
    if (!jid || jid === "status@broadcast") return;

    const text = getTextMessage(msg);
    if (!text) return;

    console.log(`[MESSAGE] ${jid}: ${text}`);

    try {
      if (text.toLowerCase() === `${PREFIX}menu`) {
        await sock.sendMessage(jid, { text: getMenu() });
        return;
      }

      if (text.toLowerCase() === `${PREFIX}ping`) {
        await sock.sendMessage(jid, { text: "🏓 Pong!\nBot aktif." });
        return;
      }

      if (text.toLowerCase().startsWith(`${PREFIX}ai`)) {
        const prompt = text.slice(`${PREFIX}ai`.length).trim();

        if (!prompt) {
          await sock.sendMessage(jid, {
            text: `Cara penggunaan:\n${PREFIX}ai siapa kamu?`
          });
          return;
        }

        if (prompt.length > 4000) {
          await sock.sendMessage(jid, {
            text: "Pertanyaan terlalu panjang. Maksimal 4000 karakter."
          });
          return;
        }

        await sock.sendPresenceUpdate("composing", jid);
        const answer = await askAI(prompt);
        await sock.sendMessage(jid, { text: answer });
        await sock.sendPresenceUpdate("paused", jid);
        return;
      }

      if (AUTO_AI && !text.startsWith(PREFIX)) {
        if (text.length > 4000) {
          await sock.sendMessage(jid, { text: "Pesan terlalu panjang." });
          return;
        }

        await sock.sendPresenceUpdate("composing", jid);
        const answer = await askAI(text);
        await sock.sendMessage(jid, { text: answer });
        await sock.sendPresenceUpdate("paused", jid);
      }
    } catch (error) {
      console.error("ERROR MESSAGE:", error);
      try {
        await sock.sendMessage(jid, {
          text: "❌ Terjadi kesalahan saat memproses pesan. Coba lagi."
        });
      } catch (sendError) {
        console.error("ERROR SEND:", sendError);
      }
    }
  });
}

process.on("uncaughtException", console.error);
process.on("unhandledRejection", console.error);

startBot().catch((error) => {
  console.error("BOT ERROR:", error);
  process.exit(1);
});
;
